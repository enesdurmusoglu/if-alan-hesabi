import UIKit

print("Çember Alanı (1)")
print("Dikdörtgen Alanı (2)")

let secim = 2
let kısaKenar = 10
let uzunKenar = 20
let yarıçap = 4.0

print("Seçiminiz : \(secim)")

if secim == 1 {
    print("Dikdörtgen Alanı")
    print("kısakenar : \(kısaKenar)")
    print("uzunkenar : \(uzunKenar)")
    let alan = kısaKenar * uzunKenar
    print("Sonuç : \(alan)")
}

if secim == 2 {
    print("Çember Alanı")
    print("Yarıçap : \(yarıçap)")
    let alan = 3.14 * yarıçap * yarıçap
    print("Sonuç : \(alan)")
    
}
